#include<stdio.h>
struct process{
  int id;
  int at;
  int bt;
  int twt;
  int tat;
  };
  struct process p[10];
  int main()
  {
  		int n,c,over=0,t,i,j,time=0,start;
  		float avgwt,avgtat,twt=0,tat=0;
  		printf("enter n:");
  		scanf("%d",&n);
  		int a[n];
  		printf("PID AT BT\n");
  		for(i=0;i<n;i++)
  		{  
  			scanf("%d %d %d",&p[i].id,&p[i].at,&p[i].bt);
  			
     
  		} 					
  	for(i=0;i<n-1;i++)
  	{
  		for(j=i+1;j<n;j++)
  		{
  			
  			if(p[i].at>p[j].at)
  			{
  			t=p[i].at;
  			p[i].at=p[j].at;
  			p[j].at=t;
  			t=p[i].bt;
  			p[i].bt=p[j].bt;
  			p[j].bt=t;
  		}
  	}
  	}
  	
  	while(over<n)
  	{
  		c=0;
  		for(i=over;i<n;i++)
  		{
  			if(p[i].at<=time)
  			  c++;
  			else
  			 break;
  		}
  		if(c>1)
  		{
  			for(i=over;i<over+c-1;i++)
  	        {
  		for(j=i+1;j<over+c;j++)
  		{
  			
  			if(p[i].bt>p[j].bt)
  			{
  			t=p[i].bt;
  			p[i].bt=p[j].bt;
  			p[j].bt=t;
  			t=p[i].at;
  			p[i].at=p[j].at;
  			p[j].at=t;
  			
  		}
  	}
  	}
  	}
  	/*for(i=0;i<n;i++)
  		{
  		
  			printf("%d %d %d\n",p[i].id,p[i].at,p[i].bt);
  		}
  		}*/
  		start=time;
  		time+=p[over].bt;
  		printf("ct:%d\n",time);
  		p[over].twt=time-p[over].at-p[over].bt;
  		p[over].tat=time-p[over].at;
  		over++;
  	}
  	//start is excution start time
  	//time holds end time	
  	printf("ID TAT WT\n");
         for(int i=0;i<n;i++)
         {
         printf("%d %d %d",i+1,p[i].tat,p[i].twt);
            	  tat=tat+p[i].tat;
       	  twt=twt+p[i].twt;
           printf("\n");
           
         }  
         
         avgwt=twt/n;
         avgtat=tat/n;
         //printf("%f %f",avgtat,avgwt);
         printf("avg wt is %.2f\n",avgwt);
         printf("avg tat is %.2f\n",avgtat);
        } 
  			 
  						
  			
  			
  				
  		
  			
