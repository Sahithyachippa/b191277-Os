#include<stdio.h>
struct process{
  int id;
  int at;
  int bt;
  int twt;
  int tat;
  int c;
  };
  struct process p[10];
  int main()
  {
  		//int n,c,over=0,t,i,j,time=0,start;
  		int n;
  		float avgwt,avgtat,twt=0,tat=0;
  		printf("enter n:");
  		scanf("%d",&n);
  		printf("PID AT BT\n");
  		for(int i=0;i<n;i++)
  		{  
  			scanf("%d %d %d",&p[i].id,&p[i].at,&p[i].bt);
  			
     
  		} 
  		int i,j;
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-i-1;j++){
			if(p[j].at>p[j+1].at){
				int t1=p[j].at;
				p[j].at=p[j+1].at;
				p[j+1].at=t1;
				int t2=p[j].bt;
				p[j].bt=p[j+1].bt;
				p[j+1].bt=t2;
				}
			}
		}
		int value;
	p[0].c=p[0].at+p[0].bt;
	for(int i=1;i<n;i++){ 
		if(p[i].at>p[i-1].c){
			value=p[i].at-p[i-1].c;
			p[i].c=p[i-1].c+p[i].bt+value;
		}
		else
			p[i].c=p[i-1].c+p[i].bt;
		
	}

	for(int i=0;i<n;i++){
	printf("%d\n",p[i].c);
		p[i].tat=p[i].c-p[i].at;
		p[i].twt=p[i].tat-p[i].bt;
	}
	printf("ID TAT WT\n");
	for(int i=0;i<n;i++)
         {
         printf("%d %d %d\n",i+1,p[i].tat,p[i].twt);
            	  tat=tat+p[i].tat;
       	  twt=twt+p[i].twt;
       	  }
       	  avgwt=twt/n;
         avgtat=tat/n;
         printf("avg wt is %.2f\n",avgwt);
         printf("avg tat is %.2f\n",avgtat);
        } 
