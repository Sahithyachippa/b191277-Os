#include<stdio.h>
struct Process{
     int at;
     int bt;
     int id;
     int rt;
     int twt;
    int tat;
     };
 struct Process a[10];
int main()
{
   int b[10];
     int n,q,c=0,ct=0;
     float avgwt,avgtat,twt=0,tat=0;
     printf("enter no.of processes:");
     scanf("%d",&n);
     printf("enter time quantum:");
     scanf("%d",&q);
     printf("ID AT BT\n");
     for(int i=0;i<n;i++)
     {
     //a[i].id=i+1;
     scanf("%d %d %d",&a[i].id,&a[i].at,&a[i].bt);
     printf("\n");
     
     a[i].rt=a[i].bt;
     
     }
     
     
     /*int trt=0;
     for(int i=0;i<n;i++)
     {
     
         trt+=a[i].rt;   
     }
     //int ct=0;*/
    
     while(c<n)
     {
        for(int i=0;i<n;i++)
        {
          if(a[i].rt>0)
          {
          /* if(a[i].rt<=q)
            {
             ct=ct+a[i].rt;
             //trt=trt-a[i].rt;
             a[i].rt=0;
             c++;
              //a[i].twt=ct-a[i].at-a[i].bt;
              //a[i].tat=ct-a[i].at;
             // twt=twt+a[i].twt;
              //tat=tat+a[i].tat;
              int w=ct-a[i].bt-a[i].at;
              int t=ct-a[i].at;
              twt=twt+w;
              tat=tat+t;
            }
            else
            {
             ct=ct+q;
             //trt=trt-q;
             a[i].rt=a[i].rt-q;
            // a[i].twt=ct-a[i].at-a[i].bt;
             //twt=twt+a[i].twt;
             //avgtat=avgtat+ct-a[i].at;
             }
            }
           
           }
           
           
          } */
           
          int et=a[i].rt<q?a[i].rt:q;
         // printf("et %d",et);
          a[i].rt-=et;
          b[i]=a[i].rt;
          ct=ct+et;
        // printf("ct %d\n",ct);
          if(a[i].rt==0)
          {
                               
              printf("ct %d\n",ct);
               a[i].tat=ct-a[i].at;
           
               a[i].twt=ct-a[i].bt-a[i].at;
              
               
               c++;
               
           }
          }
          
          
      }
      }     
         
         printf("ID TAT WT\n");
         for(int i=0;i<n;i++)
         {
         
         printf("%d %d %d",i+1,a[i].tat,a[i].twt);
            	  tat=tat+a[i].tat;
       	  twt=twt+a[i].twt;
           printf("\n");
         }  
         avgwt=twt/n;
         avgtat=tat/n;
         printf("avg wt is %.2f\n",avgwt);
         printf("avg tat is %.2f\n",avgtat);
        } 
             
                 
     
         
          
