#include<stdio.h>
#define MAX 3
int main()
{
int n,i,j;
printf("enter size of reference string:");
scanf("%d",&n);
int rs[n];
printf("enter  reference string:");
   for(i=0;i<n;i++)
   {
 	scanf("%d",&rs[i]);
   }
   int rcount[MAX]={0};
   int pfault=1;
   int frames[MAX]={0};
   
   for(i=0;i<n;i++)
   {
   	int cp=rs[i];
   	int pfound=0;
   	for(j=0;j<MAX;j++)
   	{
   		if(frames[j]==cp)
   		{
   			pfound=1;
   			rcount[j]=i;
   			break;
   		}
   	}
   	if(!pfound)
   	{
   	int lrecent=0;
   	for(j=1;j<MAX;j++)
   	{
   		if(rcount[j]<rcount[lrecent])
   		{
   		lrecent=j;
   		}
   	}
   	frames[lrecent]=cp;
   	rcount[lrecent]=i;
   	pfault++;
   	}
   }
   printf("no.of page faults are %d",pfault);
   }			
   
   	
 	

