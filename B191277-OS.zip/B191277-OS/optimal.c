
#include <stdio.h>

#define MAX 3

int main() {
int n;
printf("enter th size of reference string:");
scanf("%d",&n);
int rs[n];
printf("emter the reference string:");
 for(int i=0;i<n;i++)
 {
  scanf("%d",&rs[i]);
 } 

    int frames[MAX] = {0};
    int pfaults = 1;

    for (int i = 0; i < n; i++) {
        int cp = rs[i];
        int pfound = 0;

        for (int j = 0; j < MAX; j++) {
            if (frames[j] == cp) {
                pfound = 1;
                break;
            }
        }

        if (!pfound) {
            int replaceIndex = -1;
            int farthestPage = -1;

            for (int j = 0; j < MAX; j++) {
                int nextPage = -1;
                for (int k = i + 1; k <n; k++) {
                    if (rs[k] == frames[j]) {
                        nextPage = k;
                        break;
                    }
                }

                if (nextPage == -1) {
                    replaceIndex = j;
                    break;
                }

                if (nextPage > farthestPage) {
                    farthestPage = nextPage;
                    replaceIndex = j;
                }
            }

            frames[replaceIndex] = cp;
            pfaults++;
        }
    }

    printf("Number of page faults: %d\n", pfaults);

    return 0;
}



